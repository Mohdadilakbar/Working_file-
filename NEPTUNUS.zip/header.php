<style type="text/css">
    .header-inner{
        background: #240A34 !important;
    }
    .audiowide-regular {
                font-family: "Audiowide", sans-serif;
                font-weight: 400;
                font-style: normal;
            }
</style>
<header id="header" data-transparent="true" data-fullwidth="false" class="header-mini dark">
            <div class="header-inner">
                <div class="container">
                    <!--Logo-->
                    <div id="logo">
                        <a href="index.html">
                            <span class="logo-default audiowide-regular">
                                NEPTUNUS
                            </span>
                            <span class="logo-dark audiowide-regular">
                                NEPTUNUS
                            </span>
                        </a>
                    </div>
                    <!--End: Logo-->
                    <!-- Search -->
                    <div id="search"><a id="btn-search-close" class="btn-search-close" aria-label="Close search form"><i class="icon-x"></i></a>
                        <form class="search-form" action="search-results-page.html" method="get">
                            <input class="form-control" name="q" type="search" placeholder="Type & Search..."/>
                            <span class="text-muted">Start typing & press "Enter" or "ESC" to close</span>
                        </form>
                    </div>
                    <!-- end: search -->
                    <!--Header Extras-->
                    <div class="header-extras">
                        <ul>
                            <li>
                                <a id="btn-search" href="#"> <i class="icon-search"></i></a>
                            </li>
                            <li>
                                <a href="#"> <i class="icon-globe"></i></a>
                            </li>
                           <li>
                               <a href="#"><i class="icon-phone-incoming"></i></a>
                           </li>
                        </ul>
                    </div>
                    <!--end: Header Extras-->
                    <!--Navigation Resposnive Trigger-->
                    <div id="mainMenu-trigger">
                        <a class="lines-button x"><span class="lines"></span></a>
                    </div>
                    <!--end: Navigation Resposnive Trigger-->
                    <!--Navigation-->
                    <div id="mainMenu">
                        <div class="container">
                            <nav>
                                <ul>
                                    <li class="dropdown"><a href="#">About Us</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="#">Our Board</a></li>
                                            <li><a href="#">Accreditations</a></li>
                                            <li><a href="#">Leadership End</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Our Services</a></li>
                                    <li><a href="#">Facilities & Infrastructure</a></li>
                                    <li><a href="#">International Agents</a></li>
                                    <li><a href="#">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <!--end: Navigation-->
                </div>
            </div>
        </header>