<style type="text/css">
	.foter_list{
		width: 25% !important;
	}
	@media only screen and (min-width: 1px) and (max-width: 520px) {
	.foter_list{
		width: 50% !important;
	}}
</style>
<footer id="footer" style="background: #240A34;
  background: -webkit-linear-gradient(to right, #240A34, #302b63, #240A34); 
  background: linear-gradient(to right, #240A34, #302b63, #240A34);">
                <div class="footer-content" style="background: url(images/footerlines.svg);    background-repeat: no-repeat;background-position-x: 100%;background-position-y: 100%;">
                    <div class="container">
                        <div class="row text-light">
                         
                            <div class="col-lg-8">
                                <div class="row">
                                    <div class="foter_list">
                                        <div class="widget">
                                            <div class="widget-title">Solutions</div>
                                            <ul class="list">
                                                <li><a href="#">Freight Forwarding</a></li>
                                                <li><a href="#">Contract Logistics</a></li>
                                                <li><a href="#">Market Access</a></li>
                                                <li><a href="#">Economic Zones</a></li>
                                                <li><a href="#">Ports & Terminals</a></li>
                                                <li><a href="#">Marine Services</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="foter_list">
                                        <div class="widget">
                                            <div class="widget-title">Industries</div>
                                            <ul class="list">
                                                <li><a href="#">Automotive</a></li>
                                                <li><a href="#">Perishables</a></li>
                                                <li><a href="#">Healthcare</a></li>
                                                <li><a href="#">Technology</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="foter_list">
                                        <div class="widget">
                                            <div class="widget-title">Insights</div>
                                            <ul class="list">
                                                <li><a href="#">Expert Insights</a></li>
                                                <li><a href="#">Thought Leadership</a></li>
                                                <li><a href="#">Whitepapers</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="foter_list">
                                        <div class="widget">
                                            <div class="widget-title">Sustainability</div>
                                            <ul class="list">
                                                <li><a href="#">ESG</a></li>
                                                <li><a href="#">Climate Change</a></li>
                                                <li><a href="#">Education</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-lg-4">
                               <div>
                                <div class="widget-title" style="font-size: 14px;font-style: normal;font-weight: 600;text-transform: uppercase;line-height: 24px;letter-spacing: 1px;margin-bottom: 20px;">Contact</div>
                                <p>Mr. Deepak Reddy, MD Neptunus Ship Builders & Recyclers Pvt Ltd.</p>
                                <p> <i class="icon-map-pin"></i> 337, Road No.5, Banjara Hills, Hyderabad, Telangana, India - 500034</p>
                                <p><i class="icon-phone"></i> +91 9848434567 </p>
                                <p><i class="fa fa-envelope"></i>  deepak@neptunus.in</p>
                                <div class="widget-title" style="font-size: 14px;font-style: normal;font-weight: 600;text-transform: uppercase;line-height: 24px;letter-spacing: 1px;margin-bottom: 20px;">Follow us</div>
                                <div class="social-icons social-icons">
                <ul>
                  <li class="social-facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                  <li class="social-twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
                  <li class="social-youtube"><a href="#"><i class="fab fa-youtube"></i></a></li>
                  <li class="social-gplus"><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                </ul>
              </div>
                               </div>
                            </div>
                        </div>
                        <hr style="background:#fff">
                        <div class="row">
                        	<div class="col-lg-12 text-light p-b-0">
                        		<ul style="list-style: none;display: flex ;
    font-size: 17px;
    line-height: 21px;margin-top: 20px;margin-bottom: 0px;"	>
                        			<li style="margin-right: 50px;color: #fff !important;"><a href="#">Privacy Policy</a></li>
                        			<li style="margin-right: 50px;color: #fff !important;"><a href="#">Sitemap</a></li>
                        			<li style="margin-right: 50px;color: #fff !important;"><a href="#">Terms and Conditions</a></li>
                        			<li style="margin-right: 50px;color: #fff !important;"><a href="#">Whistleblowing Hotline</a></li>
                        			<li style="margin-right: 50px;color: #fff !important;"><a href="#">Modern Slavery Act</a></li>
                        		</ul>
                        	</div>
                        </div>
                    </div>
                </div>
                
            </footer>