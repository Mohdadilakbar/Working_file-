<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="" />
        <meta name="description" content="" />
        <!-- Document title -->
        <title>NEPTUNUS</title>
        <!-- Stylesheets & Fonts -->
        <link href="css/plugins.css" rel="stylesheet" />
        <link href="css/style.css" rel="stylesheet" />
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
        <!-- Link Swiper's CSS -->
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Audiowide&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

        <style type="text/css">
            .audiowide-regular {
                font-family: "Audiowide", sans-serif;
                font-weight: 400;
                font-style: normal;
            }

            .swiper {
                width: 100%;
                height: 600px !important;
                margin-left: auto;
                margin-right: auto;
            }

            .swiper-slide {
                background-size: cover;
                background-position: center;
            }

            .mySwiper2 {
                height: 40%;
                width: 100%;
            }

            .mySwiper {
                height: 50%;
                width: 40%;
                box-sizing: border-box;
                padding: 10px 0;
                position: absolute;
                z-index: 99999;
                top: 40% !important;
                left: 65%;
            }

            .mySwiper .swiper-slide {
                width: 25%;
                height: 100%;
                opacity: 0.4;
            }

            .mySwiper .swiper-slide-thumb-active {
                opacity: 1;
            }

            .swiper-slide img {
                display: block;
                width: 100%;
                height: 100%;
                object-fit: cover;
            }
            .mySwiper .swiper-slide img {
                height: 130px;
                border: 1px solid #fff;
            }
            @media only screen and (min-width: 1px) and (max-width: 520px) {
                .swiper {
                    width: 100%;
                    height: 850px !important;
                    margin-left: auto;
                    margin-right: auto;
                }
                .mySwiper {
                    height: 50%;
                    width: 100%;
                    box-sizing: border-box;
                    padding: 10px 0;
                    position: absolute;
                    z-index: 99999;
                    top: 95% !important;
                    left: 15%;
                }
            }
            .btn {
                  background: #240A34;
  background: -webkit-linear-gradient(to right, #240A34, #302b63, #240A34); 
  background: linear-gradient(to right, #240A34, #302b63, #240A34);
                color: #fff;
                border: none !important;
            }
            .accordion .ac-item .ac-title {
                font-size: 2rem !important;
            }
            img {
                border-radius: 10px;
            }
        </style>
    </head>
    <body>
        <!-- Body Inner -->
        <div class="body-inner">
            <!-- Header -->
            <?php
           include'header.php'
        ?>
            <!-- end: Header -->
            <div class="swiper mySwiper2">
                <div class="swiper-wrapper">
                    <div class="swiper-slide" style="background: url(images/9112.jpg); background-size: cover;">
                        <div class="bg-overlay" style="background: transparent linear-gradient(180deg, rgba(0, 0, 0, 0.7) 0%, rgba(19, 31, 39, 0.6) 45%, rgba(0, 0, 0, 0) 100%) 0% 0% no-repeat padding-box;"></div>
                        <div class="container p-t-60">
                            <div class="col-lg-6 p-t-50 text-light">
                                <h1 class="audiowide-regular" style="font-size: 50px !important;">
                                    Environmental Impact & Sustainability Stats
                                </h1>
                                <p>
                                   Pollution Prevention Measures: Neptunus implements comprehensive pollution prevention measures, including the use of containment booms during dismantling operations. These measures have led to a significant reduction in oil spills by 40% compared to industry averages.
                                </p>
                                <a href="#" class="btn" style="background: #fff; color: #000; border: none;">Learn More</a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide" style="background: url(images/5019.jpg); background-size: cover;background-position-y: 700px;">
                        <div class="bg-overlay" style="background: transparent linear-gradient(180deg, rgba(0, 0, 0, 0.7) 0%, rgba(19, 31, 39, 0.6) 45%, rgba(0, 0, 0, 0) 100%) 0% 0% no-repeat padding-box;"></div>
                        <div class="container p-t-50">
                            <div class="col-lg-6 p-t-50 text-light">
                                <h1 class="audiowide-regular" style="font-size: 50px !important;">
                                    Recycling Process
                                </h1>
                                <p>Neptunus employs a systematic approach to ship recycling, beginning with the meticulous inspection and clearance process conducted by relevant authorities such as maritime boards, customs, and environmental agencies. Upon receiving clearances, ships are safely brought to shore by tugboats and maneuvered onto a dedicated rail track known as a slipway.</p>
                                <a href="#" class="btn" style="background: #fff; color: #000; border: none;">Learn More</a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide" style="background: url(images/rest-hours-overtime-duties-offshore_909686-626.avif);background-position-y: 700px; background-size: cover;">
                        <div class="bg-overlay" style="background: transparent linear-gradient(180deg, rgba(0, 0, 0, 0.7) 0%, rgba(19, 31, 39, 0.6) 45%, rgba(0, 0, 0, 0) 100%) 0% 0% no-repeat padding-box;"></div>
                        <div class="container p-t-60">
                            <div class="col-lg-6 p-t-50 text-light">
                                <h1 class="audiowide-regular" style="font-size: 50px !important;">
                                    Quality Management
                                </h1>
                                <p>We are dedicated to implementing and enhancing our Quality, Environment, and Occupational Health and Safety management systems, aligning with our core values of human and environmental welfare. This includes adhering to ISO standards such as ISO9001:2015, ISO14001:2015, ISO45001:2018, and ISO30000:2009, ensuring the safety and environmentally friendly recycling of ships.</p>
                                <a href="#" class="btn" style="background: #fff; color: #000; border: none;">Learn More</a>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
            <div thumbsSlider="" class="swiper mySwiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="images/9112.jpg" />
                        <h5 style="color: #fff; font-family: Audiowide, sans-serif; font-weight: 400;">
                            Environmental Impact & Sustainability Stats
                        </h5>
                    </div>
                    <div class="swiper-slide">
                        <img src="images/5019.jpg" />
                        <h5 style="color: #fff; font-family: Audiowide, sans-serif; font-weight: 400;">
                            Recycling Process
                        </h5>
                    </div>
                    <div class="swiper-slide">
                        <img src="images/rest-hours-overtime-duties-offshore_909686-626.avif" />
                        <h5 style="color: #fff; font-family: Audiowide, sans-serif; font-weight: 400;">
                            Quality Management
                        </h5>
                    </div>
                    
                </div>
            </div>
            <!-- Inspiro Slider -->
            <section style="  background: #000000; /* fallback for old browsers */
  background: -webkit-linear-gradient(to right, #000000, #434343); /* Chrome 10-25, Safari 5.1-6 */
  background: linear-gradient(to right, #000000, #434343);">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 text-center text-light">
                            <h1 class="audiowide-regular text-center">Neptunus Ship Builders & Recyclers </h1>
                            <p>
                               Neptunus Ship Builders & Recyclers spearheads sustainable ship recycling, catalyzing the establishment of Guyana's top-tier Green Ship Recycling Industry Park. Our groundbreaking "Green Solution Method" utilizes impermeable concrete beds, adhering to IMO, HKC, and EU standards. Offering a holistic solution for ship recyclers, we prioritize community well-being with essential amenities. Join us in shaping a greener maritime future.
                            </p>
                            <center>
                                <a href="#" class="btn">Learn More About Us</a>
                            </center>
                        </div>
                    </div>
                </div>
            </section>
            <!--end: Inspiro Slider -->
            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <h2 class="audiowide-regular">Our Commitment</h2>
                        </div>
                        <div class="col-lg-6">
                            <div style="float: right;">
                                <a href="#" class="btn">See All Insights</a>
                            </div>
                        </div>
                    </div>
                    <div class="row p-t-30">
                        <div class="col-lg-4">
                            <img src="images/digital-composite-image-illuminated-commercial-dock-against-blue-sky_1048944-9480316.jpg" width="100%" />
                            <h4 class="audiowide-regular p-t-10">Innovation</h4>
                            <p>Our "Green Solution Method" prevents marine pollution, setting new sustainability standards. Recycling 500 ships annually and building 50 ships per year, we're revolutionizing eco-friendly practices.</p>
                            <a href="#" class="btn">Read More</a>
                        </div>
                        <div class="col-lg-4">
                            <img src="images/Boat on a river surrounded by palm trees.jpg" width="100%" />
                            <h4 class="audiowide-regular p-t-10">Environmental Responsibility</h4>
                            <p>Striving for carbon neutrality in five years, we invest 10% of project costs in Guyana's carbon credit system, prioritizing waste management and energy efficiency.</p>
                            <a href="#" class="btn">Read More</a>
                        </div>
                        <div class="col-lg-4">
                            <img src="images/2150901750.jpg" width="100%" />
                            <h4 class="audiowide-regular p-t-10">Community Impact</h4>
                            <p>3.Creating over 22,000 jobs, we empower communities and drive economic growth. Through education, healthcare, and local development projects, we're making a tangible difference in the lives of Guyanese citizens.</p>
                            <a href="#" class="btn">Read More</a>
                        </div>
                        
                    </div>
                </div>
            </section>
            <section style="background: #f2f2f2;">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-6">
                            <h3 class="audiowide-regular">Why Choose Neptunus</h3>
                            <p>With contributions of <b>USD 3 billion to Guyana's GDP and USD 300 million</b> in annual revenue for the government, the Neptunus Project is more than just a vision - it's a reality. Our track record of success speaks for itself, demonstrating our ability to deliver on our promises and drive tangible impact.</p>
                            <p>Safety and Compliance: Your safety is our top priority. With adherence to international standards and regulations, including <b>ISO 14001 and OHSAS 18001 certifications,</b> we ensure a safe and secure working environment for our employees and partners.</p>
                            <div class="toggle accordion p-t-30">
                                <div class="ac-item">
                                    <h3 class="ac-title">Our Vision</h3>
                                    <div class="ac-content">
                                        <p>Our vision is to create a world where ship recycling facilities uphold the highest standards of cleanliness, safety, and fairness. We envision end-of-life vessels being recycled in environments that prioritize the well-being of workers, local communities, and the environment, ensuring a sustainable and responsible approach to ship disposal.</p>
                                        <a href="#">Explore</a>
                                    </div>
                                </div>
                                <div class="ac-item">
                                    <h3 class="ac-title">Our Mission</h3>
                                    <div class="ac-content">
                                        <p>Our mission is to lead the transformation of the ship recycling industry by advocating for and implementing clean, safe, and just practices globally. We are committed to denouncing harmful practices, such as beaching vessels in developing countries, and promoting sustainable solutions that respect human rights, worker dignity, and environmental integrity. Through collaboration and innovation, we strive to set new benchmarks for accountability, responsibility, and ethical conduct in the maritime sector.</p>
                                        <a href="#">Explore</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <img src="images/23858.jpg" style=" width: 100%;" />
                        </div>
                    </div>
                </div>
            </section>
            <section>
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <img src="images/2148976353.jpg" width="100%" />
                        </div>
                        <div class="col-lg-6">
                            <h1 class="audiowide-regular">Accreditations</h1>
                            <p>
                                Neptunus Ship Builders & Recyclers Pvt Ltd is accredited with a comprehensive range of leading global standards in shipbuilding, recycling, and repair. Our commitment to quality assurance and continuous improvement is evident through our adherence to the following prestigious standards.
                            </p>
                            <a href="#" class="btn">Read More</a>
                        </div>
                    </div>
                </div>
            </section>
            <!-- WELCOME -->

            <!-- end: COUNTERS -->
            <section id="page-content" class="sidebar-left" style="background: url(images/highlightsnews-shape.png);    background-repeat: no-repeat;
    background-attachment: scroll;
    background-size: 100% 561px;
    background-color: #f8f8f8;
    background-position-x: 0%;
    background-position-y: 0%;
    padding-bottom: 160px;">
                <div class="container">
                    <div class="row">
                        <!-- post content -->
                        <div class="content col-lg-8">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-lg-5">
                                            <img src="images/96042.jpg" width="100%" />
                                        </div>
                                        <div class="col-lg-7">
                                            <p>20 Years</p>
                                            <h3 class="audiowide-regular">Mr. Deepak Reddy Pillapalem</h3>
                                            <p>With 20 years of experience, Mr. Pillapalem serves as Director, overseeing operations and strategic decisions. He has a strong track record in financial planning and project execution.</p>
                                            <a href="#" class="btn">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card p-t-30">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-lg-5">
                                            <img src="images/senior-businessman-architect-hard-hat.jpg" width="100%" />
                                        </div>
                                        <div class="col-lg-7">
                                            <p>40 years</p>
                                            <h3 class="audiowide-regular">Mr. N V Ramana</h3>
                                            <p>With over 40 years in international shipping, Mr. Ramana, as Director, emphasizes community development and ethical practices. He oversees shipyard operations and dry dock works.</p>
                                            <a href="#" class="btn">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card p-t-30">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-lg-5">
                                            <img src="images/medium-shot-man-posing-with-equipment.jpg" width="100%" />
                                        </div>
                                        <div class="col-lg-7">
                                            <p>35 years</p>
                                            <h3 class="audiowide-regular">Mr. Gurudath Nadimapally</h3>
                                            <p> With 35 years in legal advisory roles, Mr. Nadimapally brings expertise in compliance to the board as Director.</p>
                                            <a href="#" class="btn">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card p-t-30">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-lg-5">
                                            <img src="images/medium-shot-smiley-man-wearing-helmet.jpg" width="100%" />
                                        </div>
                                        <div class="col-lg-7">
                                            <p>Dr. Chunduri</p>
                                            <h3 class="audiowide-regular">Dr. Jayaprada Chunduri</h3>
                                            <p> As Director, Dr. Chunduri, a Marine Biologist, contributes insights into environmental sustainability and conservation, with extensive research experience.</p>
                                            <a href="#" class="btn">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end: post content -->
                        <!-- Sidebar-->
                        <div class="sidebar sticky-sidebar col-lg-4">
                            <!--Navigation-->
                            <div class="widget">
                                <div id="mainMenu" class="menu-vertical">
                                    <div class="container">
                                        <h1 class="audiowide-regular">Our Board</h1>
                                        <a href="#" class="btn">View all</a>
                                    </div>
                                </div>
                            </div>
                            <!--end: Navigation-->
                        </div>
                        <!-- end: Sidebar-->
                    </div>
                </div>
            </section>

            <!-- Footer -->
            <?php
             include'footer.php'
            ?>
            <!-- end: Footer -->
        </div>
        <!-- end: Body Inner -->
        <!-- Scroll top -->
        <a id="scrollTop"><i class="icon-chevron-up"></i><i class="icon-chevron-up"></i></a>
        <!--Plugins-->
        <script src="js/jquery.js"></script>
        <script src="js/plugins.js"></script>
        <!--Template functions-->
        <script src="js/functions.js"></script>
        <!-- Swiper JS -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

        <!-- Initialize Swiper -->
        <script>
            var swiper = new Swiper(".mySwiper", {
                spaceBetween: 10,
                slidesPerView: 4,
                freeMode: true,
                watchSlidesProgress: true,
            });
            var swiper2 = new Swiper(".mySwiper2", {
                spaceBetween: 10,
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                thumbs: {
                    swiper: swiper,
                },
            });
        </script>
    </body>
</html>
